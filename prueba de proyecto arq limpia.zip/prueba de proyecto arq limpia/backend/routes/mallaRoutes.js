import express from "express";
import axios from "axios";

const router = express.Router();
const API_AVANCE = "https://puclaro.ucn.cl/eross/avance/avance.php";

/**
 * 🔹 Endpoint /api/avance
 * Actúa como proxy — obtiene el avance directamente desde la API oficial UCN.
 * No guarda ni lee nada desde la base de datos local.
 */
router.get("/", async (req, res) => {
  const { rut, codcarrera } = req.query;

  if (!rut || !codcarrera) {
    return res.status(400).json({ error: "Faltan parámetros: rut o codcarrera" });
  }

  try {
    // 🔸 Llamar directamente a la API UCN
    const response = await axios.get(API_AVANCE, { params: { rut, codcarrera } });
    const avance = response.data;

    if (!Array.isArray(avance)) {
      console.warn("⚠️ Avance no es array:", avance);
      return res.status(200).json(avance);
    }

    console.log(`📡 Avance recuperado de API (${avance.length} registros)`);
    return res.json(avance);

  } catch (error) {
    console.error("💥 Error al obtener avance desde la API UCN:", error.message);
    return res.status(500).json({ error: "Error al obtener avance académico" });
  }
});

export default router;
