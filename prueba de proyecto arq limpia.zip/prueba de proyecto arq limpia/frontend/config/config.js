export const CONFIG = {
  API_URL: "http://localhost:3000/api",
  UNIVERSITY: "Universidad Católica del Norte",
};
